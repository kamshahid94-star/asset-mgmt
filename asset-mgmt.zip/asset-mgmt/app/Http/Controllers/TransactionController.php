<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
     public function assetHistory($id)
    {
        return Transaction::where('asset_id',$id)
            ->orderBy('action_time','desc')
            ->get();
    }
}
