<?php

namespace App\Http\Controllers;

use App\Models\Asset;
use Illuminate\Http\Request;

class AssetController extends Controller
{
      public function index()
    {
        return Asset::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'name'=>'required',
            'serial_number'=>'required|unique:assets'
        ]);

        return Asset::create($request->all());
    }

    // Checkout
    public function checkout(Request $request, $id)
    {
        $request->validate([
            'user_id'=>'required|exists:users,id'
        ]);

        $asset = Asset::findOrFail($id);

        if (!$asset->is_available) {
            return response()->json(['error'=>'Asset already checked out'], 400);
        }

        $asset->update([
            'is_available'=>false,
            'current_user_id'=>$request->user_id
        ]);

        Transaction::create([
            'user_id'=>$request->user_id,
            'asset_id'=>$asset->id,
            'action'=>'checkout',
            'action_time'=>now()
        ]);

        return response()->json(['message'=>'Asset checked out']);
    }

    // Checkin
    public function checkin($id)
    {
        $asset = Asset::findOrFail($id);

        if ($asset->is_available) {
            return response()->json(['error'=>'Asset already in warehouse'],400);
        }

        $userId = $asset->current_user_id;

        $asset->update([
            'is_available'=>true,
            'current_user_id'=>null
        ]);

        Transaction::create([
            'user_id'=>$userId,
            'asset_id'=>$asset->id,
            'action'=>'checkin',
            'action_time'=>now()
        ]);

        return response()->json(['message'=>'Asset returned']);
    }
}
