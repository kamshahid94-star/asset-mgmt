<?php 

use App\Http\Controllers\UserController;
use App\Http\Controllers\AssetController;
use App\Http\Controllers\TransactionController;

Route::post('/users', [UserController::class, 'store']);
Route::get('/users', [UserController::class, 'index']);

Route::post('/assets', [AssetController::class, 'store']);
Route::get('/assets', [AssetController::class, 'index']);

Route::post('/assets/{id}/checkout', [AssetController::class, 'checkout']);
Route::post('/assets/{id}/checkin', [AssetController::class, 'checkin']);

Route::get('/assets/{id}/transactions', [TransactionController::class, 'assetHistory']);
